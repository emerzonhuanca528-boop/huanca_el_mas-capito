    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: {
                        sans: ['Inter', 'sans-serif'],
                        serif: ['Playfair Display', 'serif'],
                    },
                    colors: {
                        scz: {
                            light: '#ecfdf5',
                            DEFAULT: '#007a33', // Verde oficial de la bandera cruceña
                            dark: '#005623',
                            accent: '#10b981'
                        }
                    }
                }
            }
        }
    </script>

document.addEventListener('DOMContentLoaded', () => {
            try {
                // 1. Control del botón de Curiosidades
                const btnCuriosidades = document.getElementById('btn-curiosidades');
                const btnTexto = document.getElementById('btn-curiosidades-texto');
                const listaContainer = document.getElementById('lista-curiosidades-container');

                if (btnCuriosidades && listaContainer) {
                    btnCuriosidades.addEventListener('click', () => {
                        const estaOculto = listaContainer.classList.contains('hidden');
                        
                        if (estaOculto) {
                            // Mostrar la lista de curiosidades
                            listaContainer.classList.remove('hidden');
                            btnCuriosidades.setAttribute('aria-expanded', 'true');
                            btnTexto.textContent = 'Ocultar lista de curiosidades';
                        } else {
                            // Ocultar la lista de curiosidades
                            listaContainer.classList.add('hidden');
                            btnCuriosidades.setAttribute('aria-expanded', 'false');
                            btnTexto.textContent = 'De clic en el botón';
                        }
                    });
                }

                // 2. Control del menú hamburguesa en dispositivos móviles
                const mobileMenuBtn = document.getElementById('mobile-menu-btn');
                const mobileMenu = document.getElementById('mobile-menu');
                const mobileLinks = document.querySelectorAll('.mobile-link');

                if (mobileMenuBtn && mobileMenu) {
                    mobileMenuBtn.addEventListener('click', () => {
                        mobileMenu.classList.toggle('hidden');
                    });

                    // Cerrar menú automáticamente al hacer clic en una opción
                    mobileLinks.forEach(link => {
                        link.addEventListener('click', () => {
                            mobileMenu.classList.add('hidden');
                        });
                    });
                }
            } catch (error) {
                console.error('Error al inicializar la interactividad de la página:', error);
            }
        });
